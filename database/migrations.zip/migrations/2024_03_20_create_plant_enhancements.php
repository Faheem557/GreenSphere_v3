use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('plants', function (Blueprint $table) {
            $table->string('sub_category')->nullable();
            $table->json('specifications')->nullable();
            $table->json('delivery_info')->nullable();
            // Add indexes for better performance
            $table->index(['category', 'sub_category']);
            $table->index('price');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('plants', function (Blueprint $table) {
            $table->dropColumn('sub_category');
            $table->dropColumn('specifications');
            $table->dropColumn('delivery_info');
            // Drop indexes for better performance
            $table->dropIndex(['category', 'sub_category']);
            $table->dropIndex('price');
        });
    }
}; 